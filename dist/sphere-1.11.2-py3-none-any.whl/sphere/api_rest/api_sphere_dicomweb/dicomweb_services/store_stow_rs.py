""" Store DICOM objects (STOW-RS) """
