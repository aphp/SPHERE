__version__ = "1.11.2"
__version_pacs__ = "No information on the version of Sphere he created this PACS"
