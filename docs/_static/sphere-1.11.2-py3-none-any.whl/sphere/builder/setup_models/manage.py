#############################################
# Python PynetDicom Research PACS Solution
# 
# manage.py include utils to use and define a service PACS Solution
# TODO : Precision sur la license d'utilisation, la documentation et le depot

from sphere.command.parser import executeAction

if __name__ == "__main__": 
    # TODO : Ajouter la verification des fichiers et de la structure app
    executeAction()
