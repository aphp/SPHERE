from django.apps import AppConfig


class ApiAnnotationConfig(AppConfig):
    name = 'api_annotation'
