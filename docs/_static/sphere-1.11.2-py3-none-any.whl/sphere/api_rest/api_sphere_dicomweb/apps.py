from django.apps import AppConfig


class ApiSphereDicomwebConfig(AppConfig):
    name = 'api_sphere_dicomweb'
